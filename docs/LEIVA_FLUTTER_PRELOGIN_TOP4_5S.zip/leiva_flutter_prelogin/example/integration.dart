// Example only: adapt the import and LoginPage name to the actual project.
// Do not replace authentication, router configuration, or app initialization.
import 'package:flutter/material.dart';
import '../lib/leiva_prelogin/leiva_prelogin.dart';

class UnauthenticatedEntry extends StatelessWidget {
  const UnauthenticatedEntry({
    super.key,
    required this.loginBuilder,
    this.introAlreadyShown = false,
    this.onIntroShown,
  });
  final WidgetBuilder loginBuilder;
  final bool introAlreadyShown;
  final VoidCallback? onIntroShown;

  @override
  Widget build(BuildContext context) => LeivaPrelogin(
    loginBuilder: loginBuilder,
    skipIntro: introAlreadyShown,
    onLoginReady: onIntroShown,
  );
}

// Inside your existing authentication gate, only for unauthenticated users:
// UnauthenticatedEntry(
//   loginBuilder: (_) => const LoginPage(),
//   introAlreadyShown: sessionState.introShown,
//   onIntroShown: () => sessionState.markIntroShown(),
// )
// Keep this shell mounted while the login is visible. Navigate to the existing
// authenticated flow only after successful sign-in, as your project already does.
