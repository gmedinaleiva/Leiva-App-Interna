# Pedido para Codex del proyecto Flutter

Integrá el prelogin nativo del paquete adjunto `leiva_flutter_prelogin` en este
proyecto. Primero leé README.md, inspeccioná la arquitectura, el router, el gate de
autenticación, el login actual y las instrucciones AGENTS.md aplicables. Luego hacé
la integración completa sin sustituir ni reescribir la lógica de autenticación.

Tomá como referencia visual aprobada el MP4 de `reference/`. La experiencia dura
5 segundos, con login visible e interactivo a los 4,5 s. Top 4 en este orden:
Inversiones, Agro, Seguros y Turismo. Mantener transiciones suaves y el logo Leiva
Tech rodando lentamente de izquierda a derecha hasta fijarse abajo a la derecha
a los 3,9 s. Debe permanecer fijo en el login real.

Copiá el componente y los assets; fusioná el fragmento de pubspec sin duplicar el
bloque flutter. Conectá loginBuilder al login actual. Mantené el shell montado
durante el login para conservar el sello; no navegues a otro login al terminar la
intro. Ajustá la esquina inferior derecha del login para evitar superposiciones.
Conservá la política de sesiones del proyecto y evitá reproducir la intro en cada
rebuild o regreso del teclado; utilizá skipIntro y onLoginReady con el estado
existente si corresponde. Los usuarios autenticados deben seguir el flujo actual.

No agregues un reproductor de video ni dependencias externas para animar. No
incluyas reference/ en los assets de producción. No reemplaces el login por una
maqueta ni cambies el backend, credenciales, permisos o configuración Android sin
una necesidad concreta del proyecto.

Revisá compatibilidad con la versión Flutter/Dart instalada. Ejecutá formatter,
analyzer y las pruebas incluidas; corregí los errores y adaptá los tests a las
convenciones del proyecto. El paquete aún no fue compilado con Flutter: no asumas
que pasó análisis o pruebas. Probalo en Android 14 / Moto G35 si el dispositivo
está conectado. Verificá fluidez en profile, insets, teclado, retorno de background,
transición al login, sello persistente, reducción de movimiento y que la animación
se detenga después de los 5 s. Informá lo probado y cualquier limitación real.
