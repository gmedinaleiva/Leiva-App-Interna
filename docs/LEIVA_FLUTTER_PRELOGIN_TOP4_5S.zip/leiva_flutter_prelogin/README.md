# Leiva — Prelogin Flutter Top 4

Entrega para integrar la propuesta aprobada en el proyecto Flutter existente.
La referencia es `reference/leiva-android-top4-fluido-5seg-720x1600.mp4`.
No es un APK ni un proyecto Flutter completo: incluye un componente nativo,
sus recursos locales, ejemplo de integración y pruebas para ejecutar en el proyecto.

## Diseño y tiempos aprobados

- Blanco, rojo Leiva `#E30613`, acentos rosa suaves y Roboto Condensed.
- Apertura del logo: 0–0,65 s.
- Inversiones: 0,65–1,50 s.
- Agro: 1,50–2,35 s.
- Seguros: 2,35–3,20 s.
- Turismo: 3,20–4,05 s.
- Transiciones de 0,28 s con desvanecimiento y desplazamiento breve.
- Leiva Tech rueda de izquierda a derecha de 0,10 a 3,90 s y queda fijo.
- El login real se revela de 4,05 a 4,50 s; recibe interacción desde 4,50 s.
- El controlador finaliza a los 5 s y deja de producir cuadros.
- Se respeta la preferencia del sistema de reducir animaciones: acceso directo.

## Integración

1. Copiar `lib/leiva_prelogin/` y `assets/leiva_prelogin/` en la raíz del proyecto.
2. Fusionar `PUBSPEC_FRAGMENT.yaml` dentro del bloque `flutter:` existente,
   conservando los demás assets, fuentes y configuraciones.
3. Ejecutar `flutter pub get`.
4. Usar `LeivaPrelogin(loginBuilder: (_) => LoginPage())` en la rama sin sesión
   del gate de autenticación. Usar el nombre real de la pantalla del proyecto.
5. Mantener el componente montado mientras el login esté visible: la capa Tech
   pertenece al contenedor. No hacer `pushReplacement` hacia el login al finalizar
   la animación, porque eliminaría esa capa. Navegar normalmente tras autenticar.
6. Reservar la esquina inferior derecha del login para el sello Tech. El sello y
   la web no interceptan toques y se ocultan al abrir el teclado, para no tapar
   controles. Reaparecen ya fijos al cerrarlo.
7. Copiar `test/leiva_prelogin_test.dart` y ejecutar las verificaciones indicadas.

`skipIntro` permite omitir la secuencia si ya se mostró en esta sesión.
`onLoginReady` se invoca una sola vez al habilitar el login; sirve para marcar esa
condición en el estado existente. No debe utilizarse para navegar a otro login.
`showSkipButton` es opcional y está desactivado para conservar la muestra aprobada.
El almacenamiento de la preferencia queda a cargo del proyecto; no se introduce
ninguna dependencia o estado global.

## Implementación

Solo usa Flutter SDK. No requiere video_player, Lottie, Rive, permisos Android,
Internet durante la ejecución ni modificaciones de Gradle. El MP4 es referencia
visual, no un asset que deba incluirse en la app.

El arte se compone en coordenadas 720 × 1600 dentro de `SafeArea` y se escala
uniformemente para conservar las proporciones. El login real conserva su propio
layout responsive. No se fuerza orientación ni se cambia la barra del sistema.
Revisar que el padre entregue ancho y alto acotados y que no aplique un segundo
escalado. Si el proyecto ya administra SafeArea a nivel superior, revisar insets
para no duplicarlos.

Las fotos de las cuatro tarjetas se exportaron de la muestra aprobada a 624 × 462
con el encuadre y bordes preservados. Los logos provienen de los recursos aportados.
La fuente variable se incluye sin modificar y su peso se solicita con FontVariation.
La animación avanza con AnimationController/vsync, sin Timer periódico. La fluidez
real depende del dispositivo; probar en modo profile en el Moto G35 con Android 14.

## Validación pendiente en el proyecto destino

Se verificaron aquí los archivos, dimensiones, rutas y ZIP. No hay Flutter/Dart
instalados en este entorno, por lo que NO se ejecutaron `flutter analyze`, las
pruebas de widgets ni una compilación Android. No se afirma equivalencia pixel a
pixel: el login de referencia era una maqueta; aquí se conecta el login real.

Ejecutar en el proyecto:

```sh
dart format lib/leiva_prelogin test/leiva_prelogin_test.dart
flutter analyze
flutter test test/leiva_prelogin_test.dart
flutter run --profile -d <id-del-moto-g35>
```

Validar apertura fría, cuatro títulos en el orden aprobado, final a los 5 s,
login interactivo a los 4,5 s, Tech derecho y fijo desde 3,9 s, teclado abierto,
retroceso, sesión autenticada, regreso al login, fuentes grandes y reducción de
movimiento. Revisar que el splash Android existente no agregue una espera artificial.
Este componente es la experiencia Flutter después del primer frame; no reemplaza
el splash nativo previo al arranque del motor.

## Fuentes técnicas

- https://api.flutter.dev/flutter/animation/AnimationController-class.html
- https://api.flutter.dev/flutter/widgets/Image/Image.asset.html
- https://docs.flutter.dev/cookbook/design/fonts
- Licencia tipográfica: `assets/leiva_prelogin/OFL.txt`.

## Inventario

- `lib/leiva_prelogin/leiva_prelogin.dart`: componente nativo e independiente.
- `assets/leiva_prelogin/`: cuatro fotos, dos logos, fuente y licencia.
- `example/integration.dart`: patrón para conectar el login existente.
- `test/leiva_prelogin_test.dart`: pruebas de interacción y continuidad del sello.
- `PROMPT_PARA_CODEX.md`: pedido de integración listo para usar.
- `reference/`: video aprobado y secuencia de cuadros.
- `MANIFEST.json`: tamaños, dimensiones y hashes de los entregables.
